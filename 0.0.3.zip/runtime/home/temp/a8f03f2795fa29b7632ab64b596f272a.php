<?php /*a:2:{s:39:"E:\web\tp\app\home\view\index\user.html";i:1689053159;s:40:"E:\web\tp\app\home\view\common\head.html";i:1687940110;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>Meet</title>
    <link type="text/css" href="/static/css/appLight.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/appDark.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layui.css" rel="stylesheet">
    <link rel="stylesheet" href="//unpkg.com/layui@2.7.6/dist/css/layui.css">
    <link type="text/css" href="/static/css/avatar.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script>
<!--图标组件-->
<script src="/static/js/layui.js"></script>
<!--提示框组件-->
<script src="/static/js/jquery.min.js"></script>
<!--JQUERY组件-->
<script src="/static/js/common.js"></script>
<!--公共脚本-->




<div class="head" style="background: none;">

    <div class="back" onclick="back()"></div>
</div>

<div class="user" style="background: url(/static/images/avatar/1.jpg) fixed;">
    <!-- <img src="/static/images/avatar/1.jpg" width="100%"> -->
</div>
<div class="boxUser">
    <div class="userName">
        <div><?php echo htmlentities($user['username']); ?></div>
        <?php if($user['sex']==1): ?>
        <div class="sex boy">
            <i class="fas fa-mars"></i>
        </div>
        <?php else: ?>
        <div class="sex girl">
            <i class="fas fa-venus"></i>
        </div>
        <?php endif; ?>
        <!-- <div class="headEdit2" onclick="userInfo()">
            <i class="fas fa-pen"></i>
        </div> -->
    </div>
    <!-- <div class="userTags"> -->

        <!-- <div class="userTag">暂无个性签名</div> -->

        <!-- <div class="userTag addTag">
            <i class="fas fa-plus"></i>
        </div> -->
    <!-- </div> -->
    <!-- <div class="school">
        <div><?php echo htmlentities($user['school']); ?></div>
        <div class="schoolCut"></div>
        <div><?php echo htmlentities($user['education']); ?></div>
    </div> -->

    <div class="userCard">
        <div class="userCardLi">
            <div>
                <i class="far fa-user"></i>
                <span><?php echo htmlentities($user['age']); ?>岁</span>
            </div>
            <div>
                <i class="fas fa-map-marker-alt"></i>
                <span>现居<?php echo htmlentities($user['province']); ?><?php echo htmlentities($user['city']); ?></span>
            </div>

        </div>
        <div class="userCardLi">
            <div>
                <i class="fas fa-child"></i>
                <span><?php echo htmlentities($user['height']); ?>CM</span>
            </div>
            <div>
                <i class="far fa-heart"></i>
                <span><?php if($user['lock']!=1): ?>等待遇见<?php else: ?>已经遇见<?php endif; ?></span>
            </div>

        </div>
    </div>


</div>

<div class="maxImages">
    <span></span>
    <img src="" alt="" class="maxImage">
</div>

<input type="hidden" value="<?php echo htmlentities($user['id']); ?>" id="id">

<script>
    $(function () {
        var imgs = $(".postImages img");
        for (var i = 0; i < imgs.length; i++) {
            $(imgs[i]).click(function () {
                var imgUrl = $(this).attr("src");  //获取图片的地址
                $(".maxImages").css('display', 'block');
                $(".maxImage").slideDown().attr("src", imgUrl);//将图片的地址加载到新的地方放大            
            });
        }
        $(".maxImages").click(function () {
            $(".maxImages").css('display', 'none');
            $(".maxImages").css('animation', 'maxImages 0.5s 0;');
        });
    })


    $(window).scroll(function () {
        var scrollTop = $(window).scrollTop();
        if (scrollTop > 230) {
            $(".head").addClass("headBg");
        } else {
            $(".head").removeClass("headBg");
        }
    })
</script>