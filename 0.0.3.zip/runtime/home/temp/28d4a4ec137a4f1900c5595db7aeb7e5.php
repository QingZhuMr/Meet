<?php /*a:2:{s:42:"E:\web\tp\app\home\view\user\userinfo.html";i:1688035218;s:40:"E:\web\tp\app\home\view\common\head.html";i:1687940110;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>Meet</title>
    <link type="text/css" href="/static/css/appLight.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/appDark.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layui.css" rel="stylesheet">
    <link rel="stylesheet" href="//unpkg.com/layui@2.7.6/dist/css/layui.css">
    <link type="text/css" href="/static/css/avatar.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script>
<!--图标组件-->
<script src="/static/js/layui.js"></script>
<!--提示框组件-->
<script src="/static/js/jquery.min.js"></script>
<!--JQUERY组件-->
<script src="/static/js/common.js"></script>
<!--公共脚本-->



<div class="head" style="background: none;">

    <div class="back" onclick="back()"></div>

    <div class="headEdit" onclick="usersave()">保存</div>


</div>
<div class="box" style="margin-top: 68px;">
    <form id="userinfoForm" method="post">
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">昵称</div>
            <div class="userinfoBoxInput"><input type="text" name="username" placeholder="昵称" value="<?php echo htmlentities($user['username']); ?>">
            </div>
        </div>
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">身高(CM)</div>
            <div class="userinfoBoxInput"><input type="text" name="height" placeholder="身高" value="<?php echo htmlentities($user['height']); ?>">
            </div>
        </div>
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">所在省份</div>
            <div class="userinfoBoxInput"><input type="text" name="province" placeholder="省份" value="<?php echo htmlentities($user['province']); ?>">
            </div>
        </div>
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">所在城市</div>
            <div class="userinfoBoxInput"><input type="text" name="city" placeholder="城市" value="<?php echo htmlentities($user['city']); ?>"></div>
        </div>
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">毕业学校</div>
            <div class="userinfoBoxInput"><input type="text" name="school" placeholder="毕业学校" value="<?php echo htmlentities($user['school']); ?>">
            </div>
        </div>
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">最高学历</div>
            <div class="userinfoBoxInput"><input type="text" name="education" placeholder="最高学历"
                    value="<?php echo htmlentities($user['education']); ?>"></div>
        </div>
        <div class="userinfoBox">
            <div class="userinfoBoxTitle">职业</div>
            <div class="userinfoBoxInput"><input type="text" name="work" placeholder="职业" value="<?php echo htmlentities($user['work']); ?>"></div>
        </div>
        <div class="userinfoBox" style="display: none;">
            <input type="text" name="id" value="<?php echo htmlentities($user['id']); ?>">
        </div>
    </form>


</div>
<script>
    //点击注册触发
    function usersave() {

        if ($("input[name=username]").val() == '') {
            layer.msg('请输入昵称');
            return false;
        }
        if ($("input[name=height]").val() == '') {
            layer.msg('请输入身高');
            return false;
        }
        if ($("input[name=province]").val() == '') {
            layer.msg('请输入所在省份');
            return false;
        }
        if ($("input[name=city]").val() == '') {
            layer.msg('请输入所在城市');
            return false;
        }
        if ($("input[name=education]").val() == '') {
            layer.msg('请输入最高学历');
            return false;
        }
        if ($("input[name=school]").val() == '') {
            layer.msg('请输入您的学校');
            return false;
        }
        if ($("input[name=work]").val() == '') {
            layer.msg('请输入您的职业');
            return false;
        }
        $.ajax({
            url: "<?php echo url('douserinfo'); ?>",
            data: $("#userinfoForm").serialize(),
            type: 'POST',
            beforeSend: function () {
                loadIndex = layer.load(2);
            },
            success: function (data) {
                layer.close(loadIndex);
                if (data.code == 0) {
                    layer.msg(data.info);
                    setTimeout(function () {
                        window.history.back(-1);
                    }, 1000);
                } else {
                    layer.msg(data.info);
                }
            }
        });
        return false;
    }
</script>