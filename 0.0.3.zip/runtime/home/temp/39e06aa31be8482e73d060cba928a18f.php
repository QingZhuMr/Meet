<?php /*a:2:{s:48:"/www/wwwroot/meet/app/home/view/index/index.html";i:1688030036;s:48:"/www/wwwroot/meet/app/home/view/common/head.html";i:1687940110;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>Meet</title>
    <link type="text/css" href="/static/css/appLight.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/appDark.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layui.css" rel="stylesheet">
    <link rel="stylesheet" href="//unpkg.com/layui@2.7.6/dist/css/layui.css">
    <link type="text/css" href="/static/css/avatar.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script>
<!--图标组件-->
<script src="/static/js/layui.js"></script>
<!--提示框组件-->
<script src="/static/js/jquery.min.js"></script>
<!--JQUERY组件-->
<script src="/static/js/common.js"></script>
<!--公共脚本-->




<body>
    <div class="head">
        <div class="headLogo">
            <b>M<b class="headLogoText">ee</b>t</b>
            <span>Beta</span>
        </div>

    </div>

    <div class="box" style="margin-top: 80px;">
        <!-- <div class="cardImg">
            <img src="/static/images/banner.jpg" width="100%">
        </div> -->
        <div class="note">
            <h1>这世界有亿万人</h1>
            <p>但我的你只有一个</p>

        </div>


        <div class="card">
            <div class="cardLeft" onclick="meet()">
                <h1>
                    与TA相遇
                </h1>
                <p>去遇见属于自己的缘分</p>
                <div class="cardGo">开启相遇</div>
            </div>

            <div class="cardRight">
                <div class="cardYujian">
                    <h1>
                        Meet
                    </h1>
                    <p>自己遇见的TA</p>
                </div>
                <div class="cardMy" onclick="user()">
                    <h1>
                        我的
                    </h1>
                    <p>关于自己的一切</p>
                </div>
            </div>
        </div>

        <!-- <div class="card">
            <div class="cardRight">
                <div class="cardGuize">
                    <h1>
                        Meet规则
                    </h1>
                    <p>三天情侣必看规则</p>
                </div>

            </div>
            <div class="cardRight">
                <div class="cardKefu">
                    <h1>
                        Meet客服
                    </h1>
                    <p>有什么难处请找客服</p>
                </div>
            </div>
        </div> -->

        <div class="posts" style="margin-top: 30px;">
            <div class="postsTitle">
                <div class="postIcon">
                    <i class="fas fa-gift"></i>
                </div>
                <div class="postIconTitle">Meet盲盒</div>
            </div>

        </div>



    </div>

    <div class="foot">
        Meet Beta版本1.01
    </div>

    <div class="maxImages">
        <span></span>
        <img src="" alt="" class="maxImage">
    </div>



    <script>
        $(function () {
            var imgs = $(".postImages img");
            for (var i = 0; i < imgs.length; i++) {
                $(imgs[i]).click(function () {
                    var imgUrl = $(this).attr("src");  //获取图片的地址
                    $(".maxImages").css('display', 'block');
                    $(".maxImage").slideDown().attr("src", imgUrl);//将图片的地址加载到新的地方放大            
                });
            }
            $(".maxImages").click(function () {
                $(".maxImages").css('display', 'none');
                $(".maxImages").css('animation', 'maxImages 0.5s 0;');
            });
        })

    </script>
</body>