<?php /*a:2:{s:38:"E:\web\tp\app\home\view\index\map.html";i:1686985961;s:40:"E:\web\tp\app\home\view\common\head.html";i:1686985103;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>元宇宙</title>
    <link type="text/css" href="/static/css/app.css" rel="stylesheet" />
    <!-- <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" /> -->
    <link type="text/css" href="/static/css/layer.css" rel="stylesheet">
</head>
<!-- <script src="/static/js/faall.min.js"></script> -->
<!--图标组件-->
<script src="/static/js/d3js.min.js"></script>
<script src="/static/js/MapJson.js"></script>
<!--地图组件-->
<script src="/static/js/layer.js"></script>
<!--提示框组件-->

<div class="head">
    <div class="headLogo">
        <b>逐鹿<b class="headLogoText">风云</b></b>
        <span>开发版</span>
    </div>
    
</div>


<div class="map">
    <svg class="chart">

    </svg>
</div>



<script>
    

    /**
     * 基本配置 
     */
    const svgWidth = 1000;
    const svgHeight = 900;
    const padding = 10;

    const svg = d3.select(".chart")
        .attr("height", svgHeight)
        .attr("width", svgWidth);




    const x0 = padding;
    const y0 = padding;
    const x1 = svgWidth - padding * 2;
    const y1 = svgHeight - padding * 2;
    const projection = d3.geoMercator().fitExtent(
        [
            [x0, y0],
            [x1, y1],
        ], MapJson);

    console.log(projection);

    // projection = d3.geoMercator() //墨卡托投影
    //     .center([someValue, someValue])  //链式写法，.center([longitude, latitude])设置地图中心
    //     .scale([someValue])   //.scale([value])设置地图缩放
    //     .translate([someValue, someValue]) //.translate([x,y])设置偏移

    const pathGenerator = d3.geoPath()
        .projection(projection); //配置上投影

    const mapPath = svg.selectAll("path")
        .data(MapJson.features) //数据绑定
        .join("path")
        .attr("d", pathGenerator) //绘制path
        .attr("stroke-width", 0.2)
        .attr("stroke", "#000000")
        .attr("fill", "#ffffff");



</script>

<script>
    // const mapContainer = svg.append("g");
    function zoomed() {
        
        const t = d3.event.transform;
        svg.attr("transform", `translate(${t.x}, ${t.y}) scale(${t.k})`);
    }
    const zoom = d3.zoom()
        .scaleExtent([1, 5])  //设置监听范围
        .on("zoom", zoomed);  //设置监听事件

    svg.call(zoom);
</script>