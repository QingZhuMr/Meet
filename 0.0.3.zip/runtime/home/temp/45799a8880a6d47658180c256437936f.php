<?php /*a:6:{s:40:"E:\web\tp\app\home\view\index\index.html";i:1689164677;s:40:"E:\web\tp\app\home\view\common\head.html";i:1689124081;s:37:"E:\web\tp\app\home\view\index\ta.html";i:1689164566;s:39:"E:\web\tp\app\home\view\index\chat.html";i:1689168075;s:39:"E:\web\tp\app\home\view\index\meet.html";i:1689124280;s:39:"E:\web\tp\app\home\view\index\user.html";i:1689164226;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>Meet</title>
    <!-- <link type="text/css" href="/static/css/appLight.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/appDark.css" rel="stylesheet" /> -->
    <link type="text/css" href="/static/css/app.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layui.css" rel="stylesheet">
    <link rel="stylesheet" href="//unpkg.com/layui@2.7.6/dist/css/layui.css">
    <link type="text/css" href="/static/css/avatar.css" rel="stylesheet">
    <!-- <link type="text/css" href="/static/css/swiper.css" rel="stylesheet" /> -->
</head>
<script src="/static/js/faall.min.js"></script>
<!--图标组件-->
<script src="/static/js/layui.js"></script>
<!--提示框组件-->
<script src="/static/js/jquery.min.js"></script>
<!--JQUERY组件-->
<script src="/static/js/common.js"></script>
<!--公共脚本-->
<!-- <script src="/static/js/swiper.js"></script> -->




<style>
    ::-webkit-scrollbar {
        width: 0px;
    }
    .layui-tab .layui-tab-title {
        width: 100%;
        position: fixed;
        left: 0;
        bottom: 0;
        height: 58px;
        white-space: nowrap;
        font-size: 0;
        border-bottom-width: 0px;
        border-bottom-style: solid;
        border-bottom-color: #FFF;
        transition: all .2s;
        -webkit-transition: all .2s;
        /* margin-bottom: 10px; */
        display: flex;
        justify-content: space-between;
        background-color: #FFF;
        z-index: 9998;
        border-top: 1px solid #F7F7F7;
        padding-bottom: 10px;
    }

    .layui-tab>.layui-tab-title li {
        /* width: 100%; */
        min-width: 15%;
        margin: auto;
        line-height: 10px;
        color: #5A5959;
    }

    /* .layui-tab>.layui-tab-title>li i {
        font-size: 16px;
    } */

    .layui-tab>.layui-tab-title>li div {
        font-size: 12px;
        margin-top: 5px;
    }

    .layui-tab-brief>.layui-tab-title .layui-this {
        color: #166EC2;
        /* font-size: 18px; */
    }


    .layui-tab-brief>.layui-tab-more li.layui-this:after,
    .layui-tab-brief>.layui-tab-title .layui-this:after {

        border: none;
        border-radius: 0;
        border-bottom: 0px solid #166EC2;
    }

    .layui-tab {
        margin: 0px 0;
        text-align: left !important;
        /* background-color: #CBCBCB; */
        height: auto;
    }

    .layui-tab-item {
        width: 100%;
        height: auto;
        background-color: #FFF;
    }

    .layui-tab-content {
        padding: 0px 0;
    }
</style>

<div class="layui-tab layui-tab-brief">

    <div class="layui-tab-content">
        <div class="layui-tab-item " style="background-color: #F9F9F9;height: 100vh;">
            <div class="boxCard">
                <style>
    .taCard {
        width: 94.5%;
        min-height: 300px;
        margin: auto;
        background-color: #FFF;
        border-radius: 10px;
        margin-top: 30px;
        box-shadow: #E1E1E1 0px 3px 8px;
        overflow: hidden;
    }

    .taAvatar {
        width: 90px;
        height: 90px;
        overflow: hidden;
        border-radius: 45px;
        position: absolute;
        bottom: 0;
        margin-bottom: -65px;
        margin-left: 10px;
        border: 3px solid #FFF;
    }

    .taAvatar img {
        width: 100%;
        height: 100%;
    }

    .taCardTop {
        width: 100%;
        height: 160px;
        background-color: #F5B9B9;
        /* overflow: hidden; */
        background-image: url('/static/images/bg/bg.jpg');
        background-size: cover;
        position: relative;
    }

    .userInfo {
        margin-left: 110px;
    }

    .userInfoName {
        font-size: 18px;
    }

    .userChat {
        width: 120px;
        height: 40px;
        line-height: 40px;
        background-color: #166EC2;
        float: right;
        border-radius: 10px 0px 0px 0px;
        color: #FFF;
    }

    .chatBox {
        width: 100%;
        height: 100vh;
        background-color: #FFF;
        position: fixed;
        z-index: 9999;
        display: none;
    }

    .chatHead {
        width: 100%;
        height: 40px;
        overflow: hidden;
        position: fixed;
        top: 0px;
        display: flex;
        z-index: 9999;
        display: -webkit-flex;
        background-color: #F9F9F9;
        -moz-user-select: none;
        /* Firefox私有属性 */
        -webkit-user-select: none;
        /* WebKit内核私有属性 */
        -ms-user-select: none;
        /* IE私有属性(IE10及以后) */
        -khtml-user-select: none;
        /* KHTML内核私有属性 */
        -o-user-select: none;
        /* Opera私有属性 */
        user-select: none;
        /* CSS3属性 */
        justify-content: space-between;
        line-height: 40px;
        border-bottom: 1px solid #E1E1E1;
    }

    .chatBack {
        padding-left: 10px;
    }

    .chatMore {
        padding-right: 10px;
        
    }

    .chatBody {
        padding-top: 40px;
    }
</style>

<div class="chatBox" style="background-color: #F9F9F9;">
    <div class="chatHead">

        <div class="chatBack" onclick="offChat()">
            <i class="fas fa-chevron-left"></i>
        </div>
        <div>TA</div>
        <div class="chatMore">
            <i class="fas fa-grip-horizontal"></i>
        </div>

    </div>
    <div class="chatBody">
        <style>
    /**聊天样式**/
    .chat {
        width: 96%;
        height: 87vh;
        overflow-y: auto;
        margin: auto;
    }

    .chatItem {
        width: 100%;
        margin-top: 10px;
        min-height: 30px;
        color: #000;
    }

    .chatItemList {
        width: 100%;
        float: left;
        position: relative;
    }

    .triangle {
        width: 0;
        height: 0;
        border-top: 5px solid transparent;
        border-bottom: 5px solid transparent;
        border-right: 10px solid #FFF;
        position: absolute;
        left: 0;
        top: 5px;
    }

    .chatBubble {
        max-width: 70%;
        float: left;
        padding: 10px 10px;
        background-color: #FFF;
        font-size: 14px;
        border-radius: 10px;
        margin-left: 5px;
        white-space: normal;
    }

    .triangleMy {
        width: 0;
        height: 0;
        border-top: 5px solid transparent;
        border-bottom: 5px solid transparent;
        border-left: 10px solid #98E165;
        position: absolute;
        right: 0;
        bottom: 0;
        margin-bottom: 5px;
    }

    .chatBubbleMy {
        max-width: 70%;
        float: right;
        padding: 10px 10px;
        background-color: #98E165;
        font-size: 14px;
        border-radius: 10px;
        white-space: normal;
        margin-right: 5px;
    }

    .chatEnter {
        width: 100%;
        min-height: 60px;
        border-top: 1px solid #E1E1E1;
        position: fixed;
        bottom: 0;
        left: 0;
        z-index: 9999;
        display: flex;
        justify-content: space-between;
    }

    .chatEnterFrame {
        width: 88%;
        height: 30px;
        margin-top: 5px;
        margin-left: 5px;
        background-color: #FFF;
        border-radius: 5px;
        text-indent: 5px;
        /* border: 1px solid #E1E1E1; */
    }

    .chatPhiz {
        margin-top: 5px;
        margin-right: 5px;
        font-size: 29px;
        color: #848484;
    }

    /* .My{
    width: 90% !important;
  } */
</style>

<div class="boxCardBox">
    <!-- <h2>Ta</h2> -->

    <div class="chat">
        <div class="chatItem">
            <div class="chatItemList">
                <div class="triangle"></div>
                <span class="chatBubble">
                    你好，小竹。很高兴认识你！
                    很荣幸成为你的Ta，希望我们可以长长久久，一直陪伴彼此~
                </span>

            </div>
            <div style="clear: both;"></div>
        </div>

        <div class="chatItem My">
            <div class="chatItemList">
                <div class="triangleMy"></div>
                <span class="chatBubbleMy">
                    你好。很高兴认识你！
                    很荣幸成为你的Ta，希望我们可以长长久久，一直陪伴彼此~
                </span>
            </div>
            <div style="clear: both;"></div>
        </div>

        <div class="chatItem">
            <div class="chatItemList">
                <div class="triangleMy"></div>
                <span class="chatBubbleMy">
                    嘻嘻~
                </span>
            </div>
            <div style="clear: both;"></div>
        </div>

    </div>
    <div class="chatEnter">
        <input type="text" class="chatEnterFrame" name="text" placeholder="">
        <div class="chatPhiz">
            <i class="far fa-grin-squint"></i>
        </div>
    </div>
</div>
    </div>

</div>

<div class="boxCard" id="boxCard">
    <div class="boxCardBox">
        <h2>Ta</h2>
    </div>
    <div class="taCard">
        <div class="taCardTop">
            <div class="taAvatar">
                <img src="/static/images/avatar/1.jpg">
            </div>
        </div>

        <div class="taCardBottom">
            <div class="userInfo">
                <div class="userInfoName">
                    小竹
                </div>
                <div class="userTags">
                    <div class="userTag">暂无个性签名</div>
                </div>
            </div>


        </div>
        <div class="userCard" style="border-radius: 0px;
        background-color: #FFF;
        height: auto;
        text-align: center;
        text-indent: 0px;">
            <div class="userCardLi">
                <div>
                    <i class="far fa-user"></i>
                    <span><?php echo htmlentities($user['age']); ?>岁</span>
                </div>
                <div>
                    <i class="fas fa-child"></i>
                    <span><?php echo htmlentities($user['height']); ?>CM</span>
                </div>
                <div>
                    <i class="fas fa-map-marker-alt"></i>
                    <span>现居<?php echo htmlentities($user['province']); ?><?php echo htmlentities($user['city']); ?></span>
                </div>

            </div>

            <div class="userChat" onclick="onChat()">
                <i class="fas fa-comments"></i> 聊天
            </div>

        </div>


    </div>

</div>

<script>
    function onChat(){
       $(".chatBox").show();

       $("#boxCard").hide();
       $("#boxCard").addClass("notclick");//不可点击状态

    }
    function offChat(){

        $(".chatBox").hide();
        $("#boxCard").show();
        $("#boxCard").removeClass("notclick");//移除不可点击状态
    }
    
</script>
            </div>
        </div>

        <div class="layui-tab-item layui-show" style="background-color: #F5B9B9;height: 100vh;">
            <div class="boxCard" style="color: #FFF;">
                <div class="boxCard">
    <div class="boxCardBox">
        <h2>Meet</h2>
    </div>
    <img src="/static/images/shou.png" width="100%" style="opacity: 0.6;margin-top: 10vh;">
    <div class="boxCardBox" style="text-align: center;">
        <p>点击Meet</p>
    </div>
</div>
            </div>
        </div>
        <div class="layui-tab-item">
            <div class="boxCard">
                <style>
    body{
        overflow-x: hidden;
    }
    .userBg {
        width: 100%;
        height: 200px;
        overflow: hidden;
        z-index: 0;
        margin: auto;
        top: 0;

    }

    .boxCardBoxNew {
        width: 94.5%;
        min-height: 500px;
        z-index: 2;
        position: relative;
        background-color: #FFF;
        margin: auto;
        padding-top: 10px;
    }
    .taAvatarUser{
        width: 90px;
        height: 90px;
        overflow: hidden;
        border-radius: 45px;
        position: absolute;
        margin: auto;
        z-index: 3;
        border: 3px solid #FFF;
        margin-top: -20px;
        margin-left: 2%;
    }
    
</style>
<div class="userBg">
    <img src="/static/images/bg/bg.jpg" width="100%">
</div>

<div class="taAvatarUser">
    <img src="/static/images/avatar/1.jpg" width="100%">
</div>
<div class="boxCardBoxNew">

    <div class="userName" style="margin-left: 100px;">
        <div><?php echo htmlentities($user['username']); ?></div>
        <?php if($user['sex']==1): ?>
        <div class="sex boy">
            <i class="fas fa-mars"></i>
        </div>
        <?php else: ?>
        <div class="sex girl">
            <i class="fas fa-venus"></i>
        </div>
        <?php endif; ?>
        <div class="headEdit2" style="margin-right: 0%;">
            <i class="fas fa-pen"></i>
        </div>
    </div>
    <div class="userTags" style="margin-left: 100px;">

        <div class="userTag">暂无个性签名</div>

        <div class="userTag addTag">
            <i class="fas fa-plus"></i>
        </div>
    </div>

    <div class="userCard">
        <div class="userCardLi">
            <div>
                <i class="far fa-user"></i>
                <span><?php echo htmlentities($user['age']); ?>岁</span>
            </div>
            <div>
                <i class="fas fa-map-marker-alt"></i>
                <span>现居<?php echo htmlentities($user['province']); ?><?php echo htmlentities($user['city']); ?></span>
            </div>

        </div>

        <div class="userCardLi">
            <div>
                <i class="fas fa-child"></i>
                <span><?php echo htmlentities($user['height']); ?>CM</span>
            </div>
            <div>
                <i class="far fa-heart"></i>
                <span><?php if($user['lock']!=1): ?>等待遇见<?php else: ?>已经遇见<?php endif; ?></span>
            </div>

        </div>


    </div>
</div>
            </div>

        </div>
    </div>

    <ul class="layui-tab-title" style="background-color: #F9F9F9;border-top: 1px solid #E9E9E9;">
        <li>
            <i class="fas fa-comment" style="font-size: 18px;"></i>
            <div>Ta</div>
        </li>
        <li class="layui-this">
            <i class="fas fa-globe-asia" style="font-size: 18px;"></i>
            <div>Meet</div>
        </li>
        <li>
            <i class="fas fa-user-alt" style="font-size: 18px;"></i>
            <div>My</div>
        </li>
    </ul>
</div>