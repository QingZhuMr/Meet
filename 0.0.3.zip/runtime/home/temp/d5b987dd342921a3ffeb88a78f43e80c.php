<?php /*a:3:{s:38:"E:\web\tp\app\home\view\chat\chat.html";i:1686920191;s:40:"E:\web\tp\app\home\view\common\head.html";i:1686220921;s:40:"E:\web\tp\app\home\view\common\foot.html";i:1686920100;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>心动</title>
    <link type="text/css" href="/static/css/app.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layer.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script><!--图标组件-->
<script src="/static/js/layer.js"></script><!--提示框组件-->



<body>
    <div class="head">
        心动列表
    </div>

    <div class="content">
        <div class="box" style="background-color: #F9F9F9;">
            <div class="divImg">
                <!-- <div class="point">10</div> -->
                <img src="/static/images/touxiang.jpg" />
            </div>
            <div class="divText">
                <b>小熊酱🐻</b>
                <i class="divMap" style="color: #B4B2B2;font-size: 13px;">16:31</i>
                <p style="color: #B4B2B2;font-size: 13px;">
                    <span style="color: #F76565;">[未读消息：10]</span>
                    <span>小哥哥在干嘛呢？</span>
                </p>
            </div>
        </div>

        <div class="box" style="background-color: #F9F9F9;">
            <div class="divImg">
                <!-- <div class="point">25</div> -->
                <img src="/static/images/touxiang.jpg" />
            </div>
            <div class="divText">
                <b>小熊酱🐻</b>
                <i class="divMap" style="color: #B4B2B2;font-size: 13px;">16:31</i>
                <p style="color: #B4B2B2;font-size: 13px;">
                    <span style="color: #F76565;">[未读消息：99+]</span>
                    <span>小哥哥人家想你了</span>
                </p>
            </div>
        </div>

    </div>

    <div class="foot">
    <a href="<?php echo htmlentities($url); ?>/home/index/index">
        <div><i class="fas fa-heart"></i></div>
    </a>

    <a href="<?php echo htmlentities($url); ?>/home/chat/chat">
        <div><i class="fas fa-comments"></i></div>
    </a>
    <a href="<?php echo htmlentities($url); ?>/home/user/user">
        <div><i class="fas fa-user-alt"></i></div>
    </a>

</div>
   

</body>