<?php /*a:2:{s:39:"E:\web\tp\app\home\view\index\meet.html";i:1687930316;s:40:"E:\web\tp\app\home\view\common\head.html";i:1687940110;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>Meet</title>
    <link type="text/css" href="/static/css/appLight.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/appDark.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layui.css" rel="stylesheet">
    <link rel="stylesheet" href="//unpkg.com/layui@2.7.6/dist/css/layui.css">
    <link type="text/css" href="/static/css/avatar.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script>
<!--图标组件-->
<script src="/static/js/layui.js"></script>
<!--提示框组件-->
<script src="/static/js/jquery.min.js"></script>
<!--JQUERY组件-->
<script src="/static/js/common.js"></script>
<!--公共脚本-->




<div class="head">

    <div class="back" onclick="back()"></div>

</div>