<?php /*a:2:{s:41:"E:\web\tp\app\index\view\index\index.html";i:1686214237;s:40:"E:\web\tp\app\index\view\index\head.html";i:1686211989;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>心动</title>
    <link type="text/css" href="/static/css/app.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layer.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script><!--图标组件-->
<script src="/static/js/layer.js"></script><!--提示框组件-->

<body>


<div class="head">
    心动社区
</div>
<div class="content">

    <div class="adv">
        <div class="advLeft">
            <i class="fas fa-volume-down" style="color: #ffda39;"></i>
        </div>
        <div class="advRight">不要随便聊骚</div>

    </div>
    <div class="title">
        <div class="titleLeft"></div>
        <div class="titleRight">
            心动配对
        </div>
    </div>
    <div class="box">
        
        <div class="divText">
            <p>今日可配对次数：12次</p>
            <p>聊天请遵守社区公约</p>
        </div>
        <div class="divBtn">开始配对</div>
    </div>

    <div class="title">
        <div class="titleLeft"></div>
        <div class="titleRight">
            心动广场
        </div>
    </div>
    <!--心动广场卡片-->
    <div class="box">
        <div class="divImg">
            <img src="/static/images/touxiang.jpg"/>
        </div>
        <div class="divText">
            <b>小熊酱🐻</b>
            <i class="divMap">5小时前 · <span>香港</span></i>
            <p>想找一个干净的男孩，我愿意✈过去找他~</p>
        </div>
    </div>
    <div class="box">
        <div class="divImg">
            <img src="/static/images/touxiang.jpg"/>
        </div>
        <div class="divText">
            <b>小熊酱🐻</b>
            <i class="divMap">6小时前 · <span>香港</span></i>
            <p>好无聊呀~想要小🌼🌼</p>
        </div>
    </div>

</div>

<div class="foot">
    <div><i class="fas fa-heart" style="color: #ffda39;"></i></div>
    <a href="#">
        <div><i class="fas fa-comments"></i></div>
    </a>
    <a href="user/index">
        <div><i class="fas fa-user-alt"></i></div>
    </a>
</div>

<script>
    //无效JS
    function peidui() {
        layer.open({
            content: '配对成功'
            , skin: 'msg'
            , time: 2 //2秒后自动关闭
        });
    }




</script>