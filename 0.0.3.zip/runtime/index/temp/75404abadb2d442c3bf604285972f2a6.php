<?php /*a:2:{s:42:"D:\wwwroot\app\index\view\index\index.html";i:1684860594;s:41:"D:\wwwroot\app\index\view\index\head.html";i:1684859906;}*/ ?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport"
        content="width=device-width, initial-scale=1, maximum-scale=1, minimum-scale=1, user-scalable=no">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <title>imToken</title>
    <link type="text/css" href="/static/css/app.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/faall.min.css" rel="stylesheet" />
    <link type="text/css" href="/static/css/layer.css" rel="stylesheet">
</head>
<script src="/static/js/faall.min.js"></script><!--图标组件-->
<script src="/static/js/layer.js"></script><!--提示框组件-->

<body>


<div class="head">
    imToken
</div>
<div class="content">

    <div class="adv">
        <div class="advLeft">
            <i class="fas fa-volume-down" style="color: #ffda39;"></i>
        </div>
        <div class="advRight"><?php echo htmlentities($index['adv']); ?></div>

    </div>
    <div class="title">
        <div class="titleLeft"></div>
        <div class="titleRight">
            钱包
        </div>
    </div>
    <div class="box">
        <div class="img">
            <img src="<?php echo htmlentities($index['images']); ?>">

        </div>
    </div>
    <div class="box">
        <div class="text" id="copyMy">
            <?php echo htmlentities($index['address']); ?>
        </div>


        <div class="textIcon" style="position: absolute;">
            <i onclick="copyText()" class="fas fa-clone" style="color: #ffda39;"></i>
        </div>
    </div>

    <div class="title">
        <div class="titleLeft"></div>
        <div class="titleRight">
            最近充值
        </div>
    </div>
    <div class="box">
        <div class="text">
            最近没有充值
            <!--静态数据-->
        </div>

    </div>
</div>

<div class="foot">

    <div><i class="fas fa-home" style="color: #ffda39;"></i></div>

    <a href="#">
        <div><i class="fas fa-coins"></i></div>
    </a>
    <a href="#">
        <div><i class="fas fa-user-alt"></i></div>
    </a>
</div>

<script>
    //拷贝实例代码
    function copyText() {
        var Texts = document.getElementById('copyMy');
        // var Texts = "<?php echo htmlentities($index['address']); ?>";
        window.getSelection().selectAllChildren(Texts);
        document.execCommand ("Copy");
        layer.open({
            content: '<?php echo htmlentities($index['address']); ?>复制成功'
            , skin: 'msg'
            , time: 2 //2秒后自动关闭
        });
    }




</script>